# Luna

A simple Express web app ready to deploy.

## Start

```bash
npm install
npm start
```
